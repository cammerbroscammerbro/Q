import subprocess
import os

# Path to your EXE (same folder)
EXE_PATH = os.path.join(os.path.dirname(__file__), "pqc_server.exe")

def _run(*args, input_data=None):
    """Runs the pqc_server.exe with given args."""
    if not os.path.exists(EXE_PATH):
        raise FileNotFoundError("pqc_server.exe not found next to quantumsafe.py")
    
    result = subprocess.run(
        [EXE_PATH, *args],
        input=input_data,
        text=True,
        capture_output=True
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip())
    return result.stdout.strip()

def generate_keypair():
    """Generates keypair from pqc_server."""
    data = _run("genkey")
    try:
        pub, priv = data.split("|")
        return {"public": pub, "private": priv}
    except ValueError:
        raise RuntimeError("Invalid keypair output: " + data)

def encrypt(public_key, message):
    """Encrypt message using public key."""
    return _run("encrypt", public_key, input_data=message)

def decrypt(private_key, ciphertext):
    """Decrypt ciphertext using private key."""
    return _run("decrypt", private_key, input_data=ciphertext)

__all__ = ["generate_keypair", "encrypt", "decrypt"]
